package com.heartdisease;

import java.io.File;

import weka.core.Instances;
import weka.core.converters.CSVLoader;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.NumericToNominal;

public class DataLoader {

    public Instances loadData(String filePath) throws Exception {

        CSVLoader loader = new CSVLoader();
        loader.setSource(new File(filePath));

        Instances data = loader.getDataSet();

        // Last column is the class
        data.setClassIndex(data.numAttributes() - 1);

        // Convert numeric class (0/1) to nominal
        NumericToNominal convert = new NumericToNominal();
        convert.setAttributeIndices("last");
        convert.setInputFormat(data);

        data = Filter.useFilter(data, convert);

        data.setClassIndex(data.numAttributes() - 1);

        return data;
    }
}
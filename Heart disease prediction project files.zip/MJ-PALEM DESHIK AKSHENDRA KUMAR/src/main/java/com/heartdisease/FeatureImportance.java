package com.heartdisease;

import weka.attributeSelection.InfoGainAttributeEval;
import weka.core.Instances;

public class FeatureImportance {

    /**
     * Displays feature importance using Information Gain.
     */
    public void printFeatureImportance(Object model, Instances data) throws Exception {

        System.out.println("\n========================================");
        System.out.println("FEATURE IMPORTANCE (Information Gain)");
        System.out.println("========================================");

        InfoGainAttributeEval evaluator = new InfoGainAttributeEval();
        evaluator.buildEvaluator(data);

        for (int i = 0; i < data.numAttributes() - 1; i++) {

            double score = evaluator.evaluateAttribute(i);

            System.out.printf("%-25s : %.6f%n",
                    data.attribute(i).name(),
                    score);
        }

        System.out.println("========================================");
    }
}
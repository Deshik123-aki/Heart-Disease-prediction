package com.heartdisease;

import weka.classifiers.trees.RandomForest;
import weka.core.Instances;

public class ModelTrainer {

    /**
     * Train a Random Forest model.
     *
     * @param data Training dataset
     * @return Trained RandomForest model
     * @throws Exception if training fails
     */
    public RandomForest trainModel(Instances data) throws Exception {

        RandomForest model = new RandomForest();

        // Configure Random Forest
        model.setOptions(new String[]{
                "-I", "100",      // Number of trees
                "-K", "0",        // Auto-select number of features
                "-depth", "0"     // Unlimited depth
        });

        // Random seed
        model.setSeed(1);

        // Train the model
        model.buildClassifier(data);

        System.out.println("\n========================================");
        System.out.println("MODEL TRAINING");
        System.out.println("========================================");
        System.out.println("Algorithm       : Random Forest");
        System.out.println("Number of Trees : 100");
        System.out.println("Random Seed     : 1");
        System.out.println("Status          : Training Completed");
        System.out.println("========================================");

        return model;
    }
}

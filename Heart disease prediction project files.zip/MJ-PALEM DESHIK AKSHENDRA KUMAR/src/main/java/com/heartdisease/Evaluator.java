package com.heartdisease;

import java.util.Random;

import weka.classifiers.Evaluation;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;

public class Evaluator {

    public void evaluateModel(RandomForest model, Instances data) throws Exception {

        Evaluation evaluation = new Evaluation(data);

        // Perform 10-fold cross validation
        evaluation.crossValidateModel(
                new RandomForest(),
                data,
                10,
                new Random(1)
        );

        System.out.println("\n========== MODEL EVALUATION ==========");

        System.out.printf("Accuracy : %.2f%%\n", evaluation.pctCorrect());

        System.out.printf("Precision : %.4f\n", evaluation.weightedPrecision());

        System.out.printf("Recall : %.4f\n", evaluation.weightedRecall());

        System.out.printf("F1 Score : %.4f\n", evaluation.weightedFMeasure());

        System.out.println("\nConfusion Matrix:");

        double[][] matrix = evaluation.confusionMatrix();

        for (double[] row : matrix) {
            for (double value : row) {
                System.out.printf("%8.0f", value);
            }
            System.out.println();
        }
    }
}
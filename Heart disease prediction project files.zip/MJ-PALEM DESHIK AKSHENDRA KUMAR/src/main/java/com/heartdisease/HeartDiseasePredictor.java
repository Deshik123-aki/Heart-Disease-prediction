package com.heartdisease;

import java.util.Scanner;

import weka.classifiers.trees.RandomForest;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;

public class HeartDiseasePredictor {

    private double readDouble(Scanner scanner) {
        while (true) {
            try {
                return Double.parseDouble(scanner.nextLine().trim());
            } catch (Exception e) {
                System.out.print("Invalid input. Enter a number: ");
            }
        }
    }

    public void predict(RandomForest model, Instances data) {

        Scanner scanner = new Scanner(System.in);

        try {

            System.out.println("\n========================================");
            System.out.println("HEART DISEASE PREDICTION");
            System.out.println("========================================");

            Instance patient = new DenseInstance(data.numAttributes());
            patient.setDataset(data);

            System.out.print("Age: ");
            patient.setValue(0, readDouble(scanner));

            System.out.print("Sex (1=Male, 0=Female): ");
            patient.setValue(1, readDouble(scanner));

            System.out.print("Chest Pain Type (0-3): ");
            patient.setValue(2, readDouble(scanner));

            System.out.print("Resting Blood Pressure: ");
            patient.setValue(3, readDouble(scanner));

            System.out.print("Cholesterol: ");
            patient.setValue(4, readDouble(scanner));

            System.out.print("Fasting Blood Sugar (>120 =1, else 0): ");
            patient.setValue(5, readDouble(scanner));

            System.out.print("Rest ECG (0-2): ");
            patient.setValue(6, readDouble(scanner));

            System.out.print("Maximum Heart Rate: ");
            patient.setValue(7, readDouble(scanner));

            System.out.print("Exercise Induced Angina (1=Yes,0=No): ");
            patient.setValue(8, readDouble(scanner));

            System.out.print("Old Peak: ");
            patient.setValue(9, readDouble(scanner));

            System.out.print("Slope (0-2): ");
            patient.setValue(10, readDouble(scanner));

            System.out.print("CA (0-4): ");
            patient.setValue(11, readDouble(scanner));

            System.out.print("Thal (0-3): ");
            patient.setValue(12, readDouble(scanner));

            // Class is unknown
            patient.setMissing(data.classIndex());

            double prediction = model.classifyInstance(patient);
            double[] prob = model.distributionForInstance(patient);

            System.out.println("\n========================================");
            System.out.println("PREDICTION RESULT");
            System.out.println("========================================");

            if ((int) prediction == 1)
                System.out.println("Prediction : HEART DISEASE");
            else
                System.out.println("Prediction : NO HEART DISEASE");

            System.out.printf("No Heart Disease : %.2f%%\n", prob[0] * 100);
            System.out.printf("Heart Disease    : %.2f%%\n", prob[1] * 100);

            System.out.println("========================================");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
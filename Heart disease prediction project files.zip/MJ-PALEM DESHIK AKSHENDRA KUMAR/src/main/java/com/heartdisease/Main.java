package com.heartdisease;

import weka.classifiers.trees.RandomForest;
import weka.core.Instances;

public class Main {

    public static void main(String[] args) {

        try {

            System.out.println("========================================");
            System.out.println(" HEART DISEASE PREDICTION SYSTEM");
            System.out.println("========================================");

            // Load dataset
            DataLoader loader = new DataLoader();
            Instances data = loader.loadData("heart-disease.csv");

            System.out.println("\nDataset Loaded Successfully.");
            System.out.println("Instances : " + data.numInstances());
            System.out.println("Attributes: " + data.numAttributes());

            // Train model
            ModelTrainer trainer = new ModelTrainer();
            RandomForest model = trainer.trainModel(data);

            System.out.println("\nRandom Forest Model Trained Successfully.");

            // Evaluate model
            Evaluator evaluator = new Evaluator();
            evaluator.evaluateModel(model, data);

            // Feature importance
            FeatureImportance featureImportance = new FeatureImportance();
            featureImportance.printFeatureImportance(model, data);

            // Predict user input
            HeartDiseasePredictor predictor = new HeartDiseasePredictor();
            predictor.predict(model, data);

            System.out.println("\n========================================");
            System.out.println("Program Finished Successfully.");
            System.out.println("========================================");

        }catch (Exception e) {
    System.err.println("Error: " + e.getMessage());
}
    }
}